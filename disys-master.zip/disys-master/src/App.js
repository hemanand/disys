import React from 'react';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import { createStore } from 'redux';
import './App.css';
var submitdata = '';

class App extends React.Component {


	constructor(){
		super();
		this.state = {
			apisuccessdata : '',
			apigetrequestdata : [],
			initialgetrequest : false,
			listingbutton : false,
			initialpostdata : true,
			tabledata: [],
      		currentpage: 1,
      		listperpage: 3
		}
		this.handleClick = this.handleClick.bind(this);
	}
	
	apipostrequest = (event) => {
			event.preventDefault();
			var fieldvalid = true;
			if(event.target.api_eid.value === ''){ this.setState({api_eid : 'Kindly fill the Eid field'}); fieldvalid = false;}
			if(event.target.api_name.value === ''){ this.setState({api_name : 'Kindly fill the Name field'}); fieldvalid = false;}
			if(event.target.api_idbarahno.value === ''){ this.setState({api_idbarahno : 'Kindly fill the idbarahno field'}); fieldvalid = false;}
			if(event.target.api_emailaddress.value === ''){ this.setState({api_emailaddress : 'Kindly fill the emailaddress field'}); fieldvalid = false;}
			if(event.target.api_unifiednumber.value === ''){ this.setState({api_unifiednumber : 'Kindly fill the unifiednumber field'}); fieldvalid = false;}
			if(event.target.api_mobilenumber.value === ''){ this.setState({api_mobilenumber : 'Kindly fill the mobilenumber field'}); fieldvalid = false;}

			if(fieldvalid === true){

				const initialState = {
							apisuccessdata : '',
				}
				const myReducer = (state = initialState,action) => {
					const newState = {...state};
					if(action.type === 'postapi'){
						fetch(`${process.env.REACT_APP_SECRET_APIPOST_URL}`, {
						  method: 'POST',
						  body : submitdata,
						  headers: {
						  	"content-type": "application/x-www-form-urlencoded",
						    'consumer-key': 'mobile_dev',
				  			'consumer-secret': `${process.env.REACT_APP_SECRET_KEY}`,
						  }
						}).then(res => res.json())
						  .then(response => {
						  	if(response.message === "API.Common.InvalidMobileNo"){ 
						  		newState.referencenumber = 'Failure'; 
						  		this.setState({apisuccessdata : 'Post Api Failure'});
						  	}
						  	if(response.message !== "API.Common.InvalidMobileNo" && response.payload.referenceNo !== ''){
						  		newState.referencenumber = response.payload.referenceNo;
						  		this.setState({apisuccessdata : 'Post Api Success Reference No : '+response.payload.referenceNo});
								this.setState({listingbutton : true});
				  		  	    this.setState({initialpostdata : false});
						  	}
						});
					}
					if(action.type === 'getapi'){
						fetch(`${process.env.REACT_APP_SECRET_APIGET_URL}`, {
						  method: 'GET',
						  headers: {
						    'consumer-key': 'mobile_dev',
				  			'consumer-secret': `${process.env.REACT_APP_SECRET_KEY}`,
						  }
						}).then(res => res.json())
						  .then(response => {
						  	this.setState({
						  		apigetrequestdata : response.payload,
						  		tabledata : response.payload
						  	});
						});
					}
					return newState;
				}
				const store = createStore(myReducer);
				this.setState({api_eid : '',api_name : '',api_idbarahno : '',api_emailaddress : '',api_unifiednumber : '',api_mobilenumber : ''});
				submitdata = "eid="+event.target.api_eid.value+"&name="+event.target.api_name.value+"&idbarahNo="+event.target.api_idbarahno.value+"&emailAddress="+event.target.api_emailaddress.value+"&unifiedNumber="+event.target.api_unifiednumber.value+"&mobileNo="+event.target.api_mobilenumber.value;
				store.dispatch({type:'postapi'});
				store.dispatch({type:'getapi'});
				store.getState();
			}
			else{
				setTimeout(() => {
					this.setState({api_eid : '',api_name : '',api_idbarahno : '',api_emailaddress : '',api_unifiednumber : '',api_mobilenumber : ''});
				},1000);
			}
	}

	mylisting = () => {
		this.setState({initialgetrequest : true});
	}

	handleClick(event) {
	    this.setState({
	      currentpage: Number(event.target.id)
	    });
  	}

	render() {
		const listdata = this.state.initialgetrequest;
		const listingbutton = this.state.listingbutton;
		const initialpostdata = this.state.initialpostdata;

		const { tabledata, currentpage, listperpage } = this.state;

	    const indexOfLastTodo = currentpage * listperpage;
	    const indexOfFirstTodo = indexOfLastTodo - listperpage;
	    const tableresult = tabledata.slice(indexOfFirstTodo, indexOfLastTodo);

	    const tablelistdata = tableresult.map((value, index) => {
	      return (<tr key={index}><td width="100px">{value.date}</td><td width="300px">{value.description}</td><td><a href={value.image} rel="noopener" download><img src={value.image} height="150px" width="150px" alt=""/><center><Button variant="primary" type="button">Download</Button></center></a></td><td width="300px">{value.title}</td></tr>);
	    });

	    const pageNumbers = [];
	    for (let i = 1; i <= Math.ceil(tabledata.length / listperpage); i++) {
	      pageNumbers.push(i);
	    }

	    const renderPageNumbers = pageNumbers.map(number => {
	      return (<li key={number} id={number} onClick={this.handleClick}>{number}</li>);
	    });



		return (
			<div id="container">
			<Container>
				<h1>{this.state.apisuccessdata}</h1>
			</Container>
			{initialpostdata ? (
				<Container>
			<h1>API Post Request</h1>
			 <Form onSubmit={ this.apipostrequest }>
			 	<Form.Group as={Row} controlId="eid">
			    <Form.Label column sm="2">
			      EID
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="number" name="api_eid" placeholder="Enter Eid" ref="myInput"/>
			      <span style={{color:'red'}}>{this.state.api_eid}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="name">
			    <Form.Label column sm="2">
			      Name
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="text" name="api_name" placeholder="Enter Name"/>
			      <span style={{color:'red'}}>{this.state.api_name}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="idbarahno">
			    <Form.Label column sm="2">
			      Idbarahno
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="number" name="api_idbarahno" placeholder="Enter Idbarahno"/>
			      <span style={{color:'red'}}>{this.state.api_idbarahno}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="emailaddress">
			    <Form.Label column sm="2">
			      Email Address
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="text" name="api_emailaddress" placeholder="Enter Emailaddress"/>
			      <span style={{color:'red'}}>{this.state.api_emailaddress}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="unifiednumber">
			    <Form.Label column sm="2">
			      Unified Number
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="number" name="api_unifiednumber" placeholder="Enter Unifiednumber"/>
			      <span style={{color:'red'}}>{this.state.api_unifiednumber}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="mobileno">
			    <Form.Label column sm="2">
			      Mobile Number
			    </Form.Label>
			    <Col sm="10">
			      <Form.Control type="number" name="api_mobilenumber" placeholder="Enter MobileNumber"/>
			      <span style={{color:'red'}}>{this.state.api_mobilenumber}</span>
			    </Col>
			    </Form.Group>

			    <Form.Group as={Row} controlId="mobileno">
			    <Col sm="2"></Col>
			    <Col sm="10">
			    	<Button variant="primary" type="submit">API Post Request</Button>
			  	</Col>
			  	</Form.Group>
			</Form>
			</Container>
			) : ( <span></span>)}
			{listingbutton ? (<Button variant="primary" onClick={this.mylisting} type="button">Click Here To Get Api Data</Button>) : ('')}
			{listdata ? (
				<Container>
				<h1>API GET Request</h1>
				<ul id="page-numbers">
		          {renderPageNumbers}
		        </ul>
				<table border="1">
				<thead>
				<tr><td>Date</td><td>Description</td><td>Image</td><td>Title</td></tr>
				</thead>
				<tbody>
				{tablelistdata}
				{/*{
					this.state.apigetrequestdata.map((value,key) => (
						<tr key={key}>
							<td width="100px">{value.date}</td>
							<td width="300px">{value.description}</td>
							<td><a href={value.image} rel="noopener" download><img src={value.image} height="150px" width="150px" alt=""/><center><Button variant="primary" type="button">Download</Button></center></a></td>
							<td width="300px">{value.title}</td>
						</tr>
					))
				}*/}
				</tbody>
				</table>
				</Container>

			) : (
				<span></span>
			)}
			</div>
		)
	}

}

export default App;